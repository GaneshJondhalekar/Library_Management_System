from django.shortcuts import render,redirect
from django.contrib.auth.models import User,auth
from django.contrib import messages
from .forms import BookForm
from .models import Book

#Admin login based on email and password
''' Taking email and password from user and authenticated his info with database table User.
if such user present then login that user'''
def AdminLogin(request):
	if request.method=='POST':
		username = request.POST['username']
		password= request.POST['password']
		user=auth.authenticate(username=username ,password=password)
		if user is not None:
			auth.login(request,user)
			return redirect('/')
		else:
			messages.info(request,'Invalid login')
			print("Invalid")
			return render(request,'login.html')
	else:
		return render(request,'login.html')

#Admin Signup
'''Taking all the related data from user and save it with post method with csrf protection.
here all data will save in mysql database in User table'''
def register(request):
	if request.method=='POST':
		first_name=request.POST['first_name']
		last_name = request.POST['last_name']
		gmail = request.POST['email']
		username = gmail
		password1 = request.POST['password']
		password2 = request.POST['rpassword']
		if username!="":
			if password1==password2:
				if User.objects.filter(email=gmail).exists():
					messages.info(request,"email already taken")
					return redirect('register')
				
				else:
					user=User.objects.create_user(username=username, first_name=first_name, last_name=last_name, email=gmail, password=password1)
					user.save()
					return redirect('login')
					
			else:
				messages.info(request, "password incorrect")
				return redirect('register')
		else:
			messages.info(request, "username cannot be empty")
			return redirect('register')
	else:
		return render(request,'register.html')
		

def logout(request):
    auth.logout(request)
    return redirect('/')

#create an entry for book
''' Creating models for book and using that model we create form and use this form to take details of book that user wants to add and save that form
After saving it will save in Book table which migrated using model'''
def addBook(request):
	if request.user.is_authenticated:
		if request.method=='POST':
			form=BookForm(request.POST,request.FILES)
			if form.is_valid():
				f=form.save(commit=False)
				f.user_id=request.user.id
				f.save()
				return redirect('/')
				
		else:
			form=BookForm()
			return render(request,'books.html',{'form':form})
            
			
	else:
		messages.info(request,"Please login First")
		return redirect('login')
	
#Retrieve all books	
''' Retrieve all objects present in book table in database and show using html'''
def viewBook(request):
	books= Book.objects.all()
	return render(request,'home.html',{'books':books})
	
#deleting book record
''' Filter book that user want to delete using its id and delete that record from table'''
def deleteBook(request,id=None):
	if request.user.is_authenticated:
		if id:
			book=Book.objects.filter(id=id).delete()
			books= Book.objects.all()
			return render(request,'delete.html',{'books':books})
		else:
			books= Book.objects.all()
			return render(request,'delete.html',{'books':books})
	else:
		messages.info(request,"Please login First")
		return redirect('login')
	
#Updating book record	
''' Filter the book that user want to update and chage its fiels data and save '''
def updateBook(request,id=None):
	if request.user.is_authenticated:
		if id:
			if request.method=='GET':
				book=Book.objects.get(id=id)
				form=BookForm(instance=book)
				return render(request,'update.html',{'form':form, 'book':book})
			else:
				book=Book.objects.get(id=id)
				form=BookForm(request.POST,request.FILES,instance=book)
				if form.is_valid():
					form.save()
					return redirect('/')
				
		
		else:
			books= Book.objects.all()
			return render(request,'delete.html',{'books':books})
			
	else:
		messages.info(request,"Please login First")
		return redirect('login')
	
                	
		
#Admin view when admin is logged in else student view so that student can view all books.
def home(request):
	if request.user.is_authenticated:
		return render(request,"home.html")
	else:
		books= Book.objects.all()
	return render(request,'home.html',{'books':books})
